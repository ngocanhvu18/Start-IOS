//
//  TableViewController.swift
//  Display2DataTypeInTable
//
//  Created by Vu Ngoc Cong on 3/19/18.
//  Copyright © 2018 Vu Ngoc Cong. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {
    
    var re: Bool = false
    var dataSource1 = DataSource()
    var dataSource2 = DataSource2()
    @IBOutlet weak var hihi: UISwitch!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = dataSource1
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func switchDataSource(_ sender: UISwitch) {
        tableView.dataSource = sender.isOn ? dataSource1 : dataSource2
        tableView.reloadData()
    }
    
    @IBAction func unwind(for unwindSegue: UIStoryboardSegue) {
        guard let detailViewController = unwindSegue.source as? ViewController else { return }
            if let indexPath = tableView.indexPathForSelectedRow {
                hihi.isOn ? (dataSource1.arrayData[indexPath.row] = Int(detailViewController.number ?? "0") ?? 0) : (dataSource2.arr[indexPath.row] = detailViewController.number ?? "")
            } else {
                hihi.isOn ? dataSource1.arrayData.append(Int(detailViewController.number ?? "0") ?? 0) : dataSource2.arr.append(detailViewController.number ?? "")
            }
           
        tableView.reloadData()
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier ?? "") == "edit" {
            if let indexPath = tableView.indexPathForSelectedRow {
                let detailViewController = segue.destination as? ViewController
                detailViewController?.number = hihi.isOn ? "\(dataSource1.arrayData[indexPath.row])" : dataSource2.arr[indexPath.row]
            }
        }
    }
}
