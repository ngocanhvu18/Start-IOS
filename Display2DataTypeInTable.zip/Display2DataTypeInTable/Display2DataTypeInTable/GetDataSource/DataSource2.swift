//
//  DataSource2.swift
//  Display2DataTypeInTable
//
//  Created by Vu Ngoc Cong on 3/19/18.
//  Copyright © 2018 Vu Ngoc Cong. All rights reserved.
//

import Foundation
import UIKit

class DataSource2: NSObject, UITableViewDataSource {
    var arr = ["mot", "hai", "ba"]
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = arr[indexPath.row]
        return cell
    }
}
