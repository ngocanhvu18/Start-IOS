//
//  DataSource.swift
//  Display2DataTypeInTable
//
//  Created by Vu Ngoc Cong on 3/19/18.
//  Copyright © 2018 Vu Ngoc Cong. All rights reserved.
//

import Foundation
import UIKit

class DataSource : NSObject, UITableViewDataSource{
    var arrayData = Array(0...10)
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = String(arrayData[indexPath.row])
        return cell
    }
}
