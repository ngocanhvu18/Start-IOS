//
//  File.swift
//  search
//
//  Created by Apple on 10/29/17.
//  Copyright © 2017 Apple. All rights reserved.
//

import Foundation
class Phone {
    var category : String
    var name : String
    
    init(category: String, name: String) {
        self.category = category
        self.name = name
    }
}
