//
//  TableViewController.swift
//  AddEditDelete
//
//  Created by ngocanh on 3/27/18.
//  Copyright © 2018 ngocanh. All rights reserved.
//

import UIKit

class TableViewController: UIViewController {
 
    
    @IBOutlet var noDataView: UIView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var switchbt: UISwitch!
    @IBOutlet weak var footerView: UIView!
    
    
    var datanumber: DataSourceNumber?
    var dataname: DataSourceString?
    
    var hasNoData: Bool = false {
        didSet {
            hasNoData ? (tableView.tableFooterView = noDataView) : (tableView.tableFooterView = footerView)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        datanumber = DataSourceNumber()
        dataname = DataSourceString()
        datanumber?.tableViewController = self
        dataname?.tableViewController = self
        tableView.dataSource = datanumber
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        hasNoData = (dataname?.arrayString.count == 0 || datanumber?.arrNumber.count == 0) ? true : false
    }
    
    @IBAction func switchBT(_ sender: UISwitch) {
        if sender.isOn {
            tableView.dataSource = datanumber
            hasNoData = datanumber?.arrNumber.count == 0
        } else {
            tableView.dataSource = dataname
            hasNoData = dataname?.arrayString.count == 0
        }
        tableView.reloadData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let detailViewController = segue.destination as? ViewController {
            if let index = tableView.indexPathForSelectedRow {
                switchbt.isOn ? (detailViewController.name = String(datanumber?.arrNumber[index.row] ?? 0)) : (detailViewController.name = dataname?.arrayString[index.row] ?? "")
            }
        }
    }
    @IBAction func unwind(sender: UIStoryboardSegue) {
        
        if let detailViewController = sender.source as? ViewController {
            if let indexPath = tableView.indexPathForSelectedRow {
                switchbt.isOn ? (datanumber?.arrNumber[indexPath.row] = Int(detailViewController.name ?? "0") ?? 0) : (dataname?.arrayString[indexPath.row] = detailViewController.name ?? "0")
            }
            else{
                switchbt.isOn ? datanumber?.arrNumber.append(Int(detailViewController.name ?? "0") ?? 0) : dataname?.arrayString.append(detailViewController.name ?? "0")
            }
        }
        tableView.reloadData()
    }
    
}



















