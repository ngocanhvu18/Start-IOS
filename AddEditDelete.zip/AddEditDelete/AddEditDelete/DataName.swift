//
//  dataName.swift
//  AddEditDelete
//
//  Created by ngocanh on 3/27/18.
//  Copyright © 2018 ngocanh. All rights reserved.
//

import UIKit
class DataSourceString: NSObject, UITableViewDataSource {
    
    var tableViewController: TableViewController?
    var arrayString = ["Ngọc", "Anh","Khoai", "To"]
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayString.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = arrayString[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            arrayString.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            tableViewController?.hasNoData = arrayString.count == 0
             tableView.reloadData()
            
        }
    }
}
