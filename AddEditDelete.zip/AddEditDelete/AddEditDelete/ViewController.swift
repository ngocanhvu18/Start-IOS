//
//  ViewController.swift
//  AddEditDelete
//
//  Created by ngocanh on 3/27/18.
//  Copyright © 2018 ngocanh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var name: String?

    @IBOutlet weak var textField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        if name != nil{
        textField.text = name
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        name = textField.text
    }


}
