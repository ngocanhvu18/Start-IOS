//
//  GetDataNumber.swift
//  AddEditDelete
//
//  Created by ngocanh on 3/27/18.
//  Copyright © 2018 ngocanh. All rights reserved.
//

import UIKit
class DataNumber: NSObject, UITableViewDataSource {
    var number = Array(1...3)
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return number.count
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = String(number[indexPath.row])
        
    }
    
}
