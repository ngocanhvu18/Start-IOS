//
//  DetailViewController.swift
//  FoodTrackerFinal
//
//  Created by Vu Ngoc Cong on 4/4/18.
//  Copyright © 2018 Vu Ngoc Cong. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var index: Int?
    
    @IBOutlet weak var nameMealTextField: UITextField!
    @IBOutlet weak var ratingControl: RatingControl!
    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var saveButton: UIBarButtonItem!
    
    var dataService = DataServices.shared.meals
    override func viewDidLoad() {
        super.viewDidLoad()
        if index != nil {
            nameMealTextField.text = dataService[index ?? 0].name
            photoImageView.image = dataService[index ?? 0].photo
            ratingControl.rating = dataService[index ?? 0].rating
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let selectImage = info[UIImagePickerControllerOriginalImage] as? UIImage
        photoImageView.image = selectImage
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func selectImageFromLibrary(_ sender: UITapGestureRecognizer) {
        nameMealTextField.resignFirstResponder()
        let imagePickerControl = UIImagePickerController()
        imagePickerControl.delegate = self
        imagePickerControl.sourceType = .photoLibrary
        present(imagePickerControl, animated: true, completion: nil)
    }
    
    @IBAction func btnSingleton(_ sender: UIBarButtonItem) {
        if let indexPath = index {
            dataService[indexPath].name = nameMealTextField.text ?? ""
            dataService[indexPath].photo = photoImageView.image
            dataService[indexPath].rating = ratingControl.rating
        } else {
            let meal = Meal(name: nameMealTextField.text ?? "", photo: photoImageView.image, rating: ratingControl.rating)
            DataServices.shared.addNewMeal(meal!)
        }
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func cancelButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
}
